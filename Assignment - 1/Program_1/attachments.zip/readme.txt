1. Create a make file in the directory (Makefile.txt).
2. Use the command "make -f Makefile.txt".
3. Run the output file created from the "make" command.
4. ./<output file name in make file> <time-a.nist.gov/ip address>
5. Capture the output in ctime mode.
6. clean the output file using "make -f Makefile clean".

